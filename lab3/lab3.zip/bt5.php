<?php
function add(){
echo func_num_args();
}

add(2,4,5,1);