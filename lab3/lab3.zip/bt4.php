<?php
    
    $dv=array("8","10","12","15","20");
    
    $so=array_rand($dv,3);
    echo $dv[$so[0]] . "<br>";
    echo $dv[$so[1]] . "<br>";
    echo $dv[$so[2]] . "<br>";
?>