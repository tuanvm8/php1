<?php
$x = 10;
$y = 5;
echo $x + $y . "<br>";
echo $x - $y ."<br>";
echo $x * $y . "<br>";
echo $x / $y ."<br";
?>